import React, { useState, useEffect } from 'react';
import axios from '../api';

function TaskList() {
  const [tasks, setTasks] = useState([]);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');

  useEffect(() => {
    fetchTasks();
  }, []);

  const fetchTasks = async () => {
    const res = await axios.get('/tasks');
    setTasks(res.data);
  };

  const handleCreate = async () => {
    await axios.post('/tasks', { title, description });
    setTitle('');
    setDescription('');
    fetchTasks();
  };

  const handleDelete = async (id) => {
    await axios.delete(`/tasks/${id}`);
    fetchTasks();
  };

  return (
    <div>
      <h1>Tasks</h1>
      <input placeholder="Title" value={title} onChange={(e) => setTitle(e.target.value)} />
      <input placeholder="Description" value={description} onChange={(e) => setDescription(e.target.value)} />
      <button onClick={handleCreate}>Create</button>
      <ul>
        {tasks.map(task => (
          <li key={task._id}>
            {task.title} - {task.description}
            <button onClick={() => handleDelete(task._id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default TaskList;